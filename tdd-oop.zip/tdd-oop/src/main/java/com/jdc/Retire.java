package com.jdc;

public class Retire {
    private String firstName;
    private String lastName;

    public Retire(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
