package com.jdc;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.*;

public class SalaryEmployeeTest {
    private SalaryEmployee salaryEmployee;

    @BeforeEach
    public void init(){
        salaryEmployee=new SalaryEmployee("MD001",
                "John","Doe");
    }
    @Test
    public void should_return_salary_for_salary_employee(){
        salaryEmployee.setSalary(3000);
        assertThat(salaryEmployee.calculateSalary()
                ,equalTo(3000));
    }
    @Test
    public void should_return_make_charity_for_salary_employee(){
        assertThat(salaryEmployee.makeCharity(20),equalTo(20));
    }
}
